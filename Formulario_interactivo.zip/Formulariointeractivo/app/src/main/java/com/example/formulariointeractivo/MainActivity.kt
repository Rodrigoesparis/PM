package com.example.formulariointeractivo

import android.app.Activity
import android.os.Bundle
import android.widget.*

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.mainactivity)

        // Referencias
        val etNombre = findViewById<EditText>(R.id.etNombre)
        val etCorreo = findViewById<EditText>(R.id.etCorreo)
        val cbDeporte = findViewById<CheckBox>(R.id.cbDeporte)
        val cbMusica = findViewById<CheckBox>(R.id.cbMusica)
        val rgGenero = findViewById<RadioGroup>(R.id.rgGenero)
        val spPais = findViewById<Spinner>(R.id.spPais)
        val swNotificaciones = findViewById<Switch>(R.id.swNotificaciones)
        val btnEnviar = findViewById<Button>(R.id.btnEnviar)

        //Spinner
        val adapter = ArrayAdapter.createFromResource(
            this,
            R.array.paises,
            android.R.layout.simple_spinner_item
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spPais.adapter = adapter

        // Botón Enviar
        btnEnviar.setOnClickListener {
            val nombre = etNombre.text.toString()
            val correo = etCorreo.text.toString()
            val deporte = if (cbDeporte.isChecked) "Sí" else "No"
            val musica = if (cbMusica.isChecked) "Sí" else "No"

            val generoId = rgGenero.checkedRadioButtonId
            val genero = if (generoId != -1)
                findViewById<RadioButton>(generoId).text.toString()
            else
                "No especificado"

            val pais = spPais.selectedItem.toString()
            val notificaciones = if (swNotificaciones.isChecked) "Sí" else "No"

            val mensaje = "Nombre: $nombre\nCorreo: $correo\nDeporte: $deporte\nMúsica: $musica\nGénero: $genero\nPaís: $pais\nNotificaciones: $notificaciones"

            Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show()
        }
    }
}
