package com.example.recyclerview

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.parques.Park
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(R.id.ParksRecyclerView)

        val parks = listOf(
            Park("Parque Central", "Zona verde con fuentes", R.drawable.ic_launcher_background),
            Park("Jardín del Sol", "Perfecto para pasear mascotas", R.drawable.ic_launcher_background),
            Park("Bosque Norte", "Rutas de senderismo", R.drawable.ic_launcher_background)
        )

        recyclerView.adapter = ParkAdapter(parks)
        recyclerView.layoutManager = LinearLayoutManager(this)
    }
}
