package com.example.parques

data class Park(
    val name: String,
    val description: String,
    val imageRes: Int
)