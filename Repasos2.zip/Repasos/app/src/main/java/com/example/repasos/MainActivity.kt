package com.example.repasos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            
            var index by remember { mutableStateOf(0) }
            val colores = listOf("⚪", "🔴", "🟡", "🟢")


            androidx.compose.foundation.layout.Column {
                Text(
                    text = colores[index],
                    fontSize = 100.sp
                )

                Button(onClick = {
                    index = (index + 1) % colores.size
                }) {
                    Text("Cambiar color")
                }
            }
        }
    }
}
