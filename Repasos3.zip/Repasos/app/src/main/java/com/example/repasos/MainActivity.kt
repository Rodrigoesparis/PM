package com.example.repasos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                TapSurprise()
            }
        }
    }
}

@Composable
fun TapSurprise() {
    var contador by rememberSaveable { mutableStateOf(0) }

    // Determinamos qué emoji mostrar
    val emoji = if (contador >= 5) "🎁" else "📦"

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = emoji,
            fontSize = 100.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(onClick = { contador++ }) {
            Text("Tocar")
        }

        if (contador >= 5) {
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "¡Sorpresa!",
                fontSize = 24.sp
            )
        }
    }
}
