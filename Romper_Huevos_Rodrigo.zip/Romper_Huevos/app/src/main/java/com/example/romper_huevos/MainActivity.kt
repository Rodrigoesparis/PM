package com.example.romper_huevos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.draw.scale
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.unit.sp
import com.example.romper_huevos.ui.theme.Romper_HuevosTheme


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge() // Permite que la app use toda la pantalla
        setContent {
            Romper_HuevosTheme { // Tema personalizado
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Greeting(name = "Android", modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}


@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    var taps by rememberSaveable { mutableStateOf(0) } // Contador de clicks persistente
    var tapped by rememberSaveable { mutableStateOf(false) } // Animación huevo

    val maxTaps = 20
    val progress = (taps.coerceAtMost(maxTaps) / maxTaps.toFloat()) //Contador de la barra de progreso
    val percentage = (progress * 100).toInt()//Progreso de 0 a 100%

    // Animación de crecer
    val scale by animateFloatAsState( //Al pulsar animacion de crecer
        targetValue = if (tapped) 1.2f else 1f, //Al pulsar aumentar tamaño
        animationSpec = tween(durationMillis = 150) //Duración de animación
    )

    LaunchedEffect(tapped) {
        if (tapped) {
            kotlinx.coroutines.delay(150)
            tapped = false
        }
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally, //Alineación horizontal
        verticalArrangement = Arrangement.Center,//Alineación vertical
        modifier = modifier.fillMaxSize()
    ) {

        Spacer(modifier = Modifier.height(16.dp))


        LinearProgressIndicator( // Barra de progreso
            progress = progress,
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .height(8.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))


        Text( // Texto con porcentaje
            text = "$percentage%",
            fontSize = 16.sp
        )

        Spacer(modifier = Modifier.height(16.dp))


        if (taps < 10) {  // Huevo principal
            Text(
                text = "🥚",
                fontSize = 150.sp,
                modifier = Modifier
                    .clickable(enabled = taps < 20) {
                        taps++
                        tapped = true
                    }
                    .scale(scale)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))


        if (taps in 10..19) { // Emojis 10-19 taps
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "💥",
                    fontSize = 100.sp,
                    modifier = Modifier.clickable { taps++ }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "🥚",
                    fontSize = 100.sp,
                    modifier = Modifier.clickable { taps++ }
                )
            }
        }


        if (taps >= 20) { // Emoji >= 20 taps
            Text(
                text = "🐣",
                fontSize = 100.sp
            )
        }

        Spacer(modifier = Modifier.height(16.dp))


        Text( // Contador de clicks
            text = "Clicks: $taps",
            fontSize = 20.sp
        )

        Spacer(modifier = Modifier.height(16.dp))


        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) { // Botones Reset y +5
            androidx.compose.material3.Button(onClick = { taps = 0 }) {
                Text("Reset")
            }
            androidx.compose.material3.Button(
                onClick = { taps = (taps + 5).coerceAtMost(maxTaps) }
            ) {
                Text("+5")
            }
        }
    }
}




@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Romper_HuevosTheme {
        Greeting("Android")
    }
}
