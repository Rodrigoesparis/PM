package com.example.smartgarden

import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class SettingsActivity : BaseMenuActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(24, 24, 24, 24)

        val tv = TextView(this)
        tv.text = "Pantalla de Ajustes"
        tv.textSize = 24f
        layout.addView(tv)

        val btnEjemplo = Button(this)
        btnEjemplo.text = "Botón de ejemplo"
        layout.addView(btnEjemplo)

        setContentView(layout)
    }
}
