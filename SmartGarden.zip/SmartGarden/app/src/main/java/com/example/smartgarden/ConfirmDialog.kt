package com.example.smartgarden

import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import androidx.fragment.app.DialogFragment
import com.google.android.material.snackbar.Snackbar
import android.widget.Toast

class ConfirmDialog : DialogFragment() {
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            val builder = AlertDialog.Builder(it)
            builder.setTitle("Confirmación")
                .setMessage("¿Deseas guardar los datos de esta planta?")
                .setPositiveButton("Aceptar") { dialog, _ ->
                    Snackbar.make(
                        requireActivity().findViewById(android.R.id.content),
                        "Datos guardados 🌱",
                        Snackbar.LENGTH_SHORT
                    ).show()
                }
                .setNegativeButton("Cancelar") { dialog, _ ->
                    Toast.makeText(requireContext(), "Operación cancelada", Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                }
            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }
}
