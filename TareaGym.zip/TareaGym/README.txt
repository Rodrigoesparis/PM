Aplicación para añadir ejercicios o usar ejercicios ya creados y guardarlos 
junto con sus instrucciones series y repeticiones.

USO DE LA APLICACIÓN
1-Boton de rutinas
	-Pagina para ver todas las rutinas disponibles y ver la información de cada una de ellas
	-Opcion para guardar como favorito cada ejercicio o marcarla como realizada
	
2-Boton de favorito
	-Puedes ver las rutinas guardadas como favoritas y marcarlas como realizadas
	
3-Boton de notificacion
	-Muestra una notificacion para entrenar