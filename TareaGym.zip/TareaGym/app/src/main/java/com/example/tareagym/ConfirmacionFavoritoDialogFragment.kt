package com.example.tareagym

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment

class ConfirmacionFavoritoDialogFragment : DialogFragment() {

    internal lateinit var listener: ConfirmacionListener

    interface ConfirmacionListener {
        fun onDialogPositiveClick()
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        try {
            listener = parentFragment as ConfirmacionListener
        } catch (e: ClassCastException) {
            throw ClassCastException((parentFragment.toString() + " must implement ConfirmacionListener"))
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            val builder = AlertDialog.Builder(it)
            builder.setMessage("¿Añadir este ejercicio a favoritos?")
                .setPositiveButton("Aceptar") { _, _ ->
                    listener.onDialogPositiveClick()
                }
                .setNegativeButton("Cancelar") { dialog, _ ->
                    dialog.cancel()
                }
            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }
}
