package com.example.tareagym

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar

class DetalleEjercicioFragment : Fragment(), ConfirmacionFavoritoDialogFragment.ConfirmacionListener {

    private var rutina: Rutina? = null
    private lateinit var fabFavorito: FloatingActionButton

    companion object {
        private const val ARG_RUTINA = "rutina"

        fun newInstance(rutina: Rutina): DetalleEjercicioFragment {
            return DetalleEjercicioFragment().apply {
                arguments = Bundle().apply {
                    putSerializable(ARG_RUTINA, rutina)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        rutina = arguments?.getSerializable(ARG_RUTINA) as? Rutina
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_detalle_ejercicio, container, false)


        val img = view.findViewById<ImageView>(R.id.imgDetalle)
        val nombre = view.findViewById<TextView>(R.id.txtNombreDetalle)
        val reps = view.findViewById<TextView>(R.id.txtRepsDetalle)
        val nivel = view.findViewById<TextView>(R.id.txtNivelDetalle)
        val pasos = view.findViewById<TextView>(R.id.txtPasosDetalle)
        val btnCompletar = view.findViewById<Button>(R.id.btnCompletar)
        val fabAtras = view.findViewById<FloatingActionButton>(R.id.fabAtras)
        fabFavorito = view.findViewById(R.id.fabFavorito)

        // Cargar datos
        rutina?.let {
            img.setImageResource(it.fotoRes)
            nombre.text = it.nombre
            reps.text = it.reps
            nivel.text = it.nivel
            pasos.text = it.pasos
            actualizarBotonFavorito()
        }

        // Listeners
        btnCompletar.setOnClickListener {
            Snackbar.make(view, "¡Ejercicio completado!", Snackbar.LENGTH_LONG).show()
        }

        fabAtras.setOnClickListener {
            parentFragmentManager.popBackStack()
        }

        fabFavorito.setOnClickListener {
            handleFavoritoClick()
        }

        return view
    }

    private fun handleFavoritoClick() {
        rutina?.let { currentRutina ->
            if (FavoritosManager.esFavorito(currentRutina)) {
                FavoritosManager.eliminarFavorito(currentRutina)
                actualizarBotonFavorito()
                view?.let {
                    Snackbar.make(it, "Ejercicio eliminado de favoritos", Snackbar.LENGTH_LONG)
                        .setAction("Deshacer") { 
                            FavoritosManager.agregarFavorito(currentRutina)
                            actualizarBotonFavorito()
                        }.show()
                }
            } else {
                val dialog = ConfirmacionFavoritoDialogFragment()
                dialog.show(childFragmentManager, "ConfirmacionFavoritoDialog")
            }
        }
    }

    private fun actualizarBotonFavorito() {
        rutina?.let {
            if (FavoritosManager.esFavorito(it)) {
                fabFavorito.setImageResource(R.drawable.ic_favorito_filled)
            } else {
                fabFavorito.setImageResource(R.drawable.ic_favorito)
            }
        }
    }

    override fun onDialogPositiveClick() {
        rutina?.let { currentRutina ->
            FavoritosManager.agregarFavorito(currentRutina)
            actualizarBotonFavorito()
            view?.let {
                Snackbar.make(it, "Ejercicio añadido a favoritos", Snackbar.LENGTH_SHORT).show()
            }
        }
    }
}
