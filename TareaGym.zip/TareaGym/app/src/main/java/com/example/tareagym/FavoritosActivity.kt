package com.example.tareagym

import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class FavoritosActivity : BaseActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: RutinaAdapter
    private lateinit var fabAtras: FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_favoritos)

        recyclerView = findViewById(R.id.recyclerViewFavoritos)
        fabAtras = findViewById(R.id.fabAtrasFavoritos)


        adapter = RutinaAdapter(emptyList()) { rutinaSeleccionada ->
            val fragment = DetalleEjercicioFragment.newInstance(rutinaSeleccionada)
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container_favoritos, fragment)
                .addToBackStack(null)
                .commit()
        }

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        fabAtras.setOnClickListener {
            finish()
        }

        supportFragmentManager.addOnBackStackChangedListener {
            val isDetailVisible = supportFragmentManager.backStackEntryCount > 0
            recyclerView.visibility = if (isDetailVisible) View.GONE else View.VISIBLE
            fabAtras.visibility = if (isDetailVisible) View.GONE else View.VISIBLE
        }
    }

    override fun onResume() {
        super.onResume()
        adapter.actualizarLista(FavoritosManager.getFavoritos())
    }
}
