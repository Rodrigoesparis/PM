package com.example.tareagym

object FavoritosManager {

    private val favoritos = mutableSetOf<Rutina>()

    fun agregarFavorito(rutina: Rutina) {
        favoritos.add(rutina)
    }

    fun eliminarFavorito(rutina: Rutina) {
        favoritos.remove(rutina)
    }

    fun esFavorito(rutina: Rutina): Boolean {
        return favoritos.contains(rutina)
    }

    fun getFavoritos(): List<Rutina> {
        return favoritos.toList()
    }
}
