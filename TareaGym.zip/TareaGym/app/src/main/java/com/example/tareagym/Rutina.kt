package com.example.tareagym

import java.io.Serializable

data class Rutina(
    val nombre: String,
    val reps: String,
    val nivel: String,
    val pasos: String,
    val fotoRes: Int,
) : Serializable {
    companion object {
        fun dummyData(): List<Rutina> {
            return listOf(
                Rutina(
                    "Flexiones", "10 rep", "Principiante",
                    "1. Manos a la altura de los hombros...\n2. Baja el pecho hasta casi tocar el suelo...\n3. Sube de forma controlada.",
                    R.drawable.flexion,
                ),
                Rutina(
                    "Sentadillas", "15 rep", "Intermedio",
                    "1. Pies a la anchura de las caderas...\n2. Baja la cadera como si te sentaras...\n3. Mantén la espalda recta.",
                    R.drawable.sentadilla,
                ),
                Rutina(
                    "Plancha", "30 seg", "Avanzado",
                    "1. Apoya los antebrazos en el suelo...\n2. Mantén el cuerpo recto como una tabla...\n3. Contrae el abdomen.",
                    R.drawable.plancha,
                )
            )
        }
    }
}
