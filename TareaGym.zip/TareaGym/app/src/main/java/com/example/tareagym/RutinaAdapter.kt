package com.example.tareagym

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RutinaAdapter(
    private var lista: List<Rutina>,
    private val listener: (Rutina) -> Unit
) : RecyclerView.Adapter<RutinaAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val nombre: TextView = view.findViewById(R.id.txtNombre)
        private val repeticiones: TextView = view.findViewById(R.id.txtReps)
        private val nivel: TextView = view.findViewById(R.id.txtNivel)
        private val foto: ImageView = view.findViewById(R.id.imgRutina)

        fun bind(rutina: Rutina) {
            nombre.text = rutina.nombre
            repeticiones.text = rutina.reps
            nivel.text = rutina.nivel
            foto.setImageResource(rutina.fotoRes)
            itemView.setOnClickListener { listener(rutina) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_rutina, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(lista[position])
    }

    override fun getItemCount(): Int = lista.size
    fun actualizarLista(nuevaLista: List<Rutina>) {
        lista = nuevaLista
        notifyDataSetChanged()
    }
}
