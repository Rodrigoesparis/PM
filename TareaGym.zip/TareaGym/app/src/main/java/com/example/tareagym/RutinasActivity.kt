package com.example.tareagym

import android.os.Bundle
import android.view.View
import androidx.fragment.app.FragmentManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class RutinasActivity : BaseActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var fabAtras: FloatingActionButton
    private val listaRutinas = Rutina.dummyData()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rutinas)

        recyclerView = findViewById(R.id.recyclerViewRutinas)
        recyclerView.layoutManager = LinearLayoutManager(this)
        fabAtras = findViewById(R.id.fabAtrasRutinas)

        fabAtras.setOnClickListener {
            finish()
        }

        supportFragmentManager.addOnBackStackChangedListener {
            actualizarVisibilidadBoton()
        }

        val adapter = RutinaAdapter(listaRutinas) { rutinaSeleccionada ->
            val fragment = DetalleEjercicioFragment.newInstance(rutinaSeleccionada)

            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit()
        }

        recyclerView.adapter = adapter

        actualizarVisibilidadBoton()
    }

    private fun actualizarVisibilidadBoton() {
        if (supportFragmentManager.backStackEntryCount > 0) {
            fabAtras.visibility = View.GONE
        } else {
            fabAtras.visibility = View.VISIBLE
        }
    }
}
