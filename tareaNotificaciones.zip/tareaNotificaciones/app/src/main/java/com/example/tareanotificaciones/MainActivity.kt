package com.example.tareanotificaciones

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    private lateinit var notificationHelper: NotificationHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        notificationHelper = NotificationHelper(this)

        // Crear canal de notificación al iniciar
        notificationHelper.crearCanal()

        setupButtons()
    }

    private fun setupButtons() {
        // Botón para mostrar Toast
        findViewById<Button>(R.id.btnToast).setOnClickListener {
            mostrarToast()
        }

        // Botón para mostrar Snackbar
        findViewById<Button>(R.id.btnSnackbar).setOnClickListener {
            mostrarSnackbar()
        }

        // Botón para enviar notificación
        findViewById<Button>(R.id.btnNotificacion).setOnClickListener {
            // Verificar permiso en Android 13+
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                // Solicitar permiso
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    1
                )
            } else {
                // Ya tiene permiso o es Android < 13
                enviarNotificacion()
            }
        }
    }

    private fun mostrarToast() {
        Toast.makeText(
            this,
            "Recordatorio: El parque cierra a las 20:00",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun mostrarSnackbar() {
        val rootView = findViewById<android.view.View>(android.R.id.content)
        Snackbar.make(rootView, "Notificación enviada al sistema", Snackbar.LENGTH_LONG)
            .setAction("Deshacer") {
                Toast.makeText(this, "Acción deshecha - Notificación cancelada", Toast.LENGTH_SHORT).show()
            }
            .setActionTextColor(ContextCompat.getColor(this, android.R.color.holo_red_light))
            .show()
    }

    private fun enviarNotificacion() {
        notificationHelper.mostrarNotificacionCierre()
        Toast.makeText(this, "Notificación programada para el cierre", Toast.LENGTH_SHORT).show()
    }

    // Manejar resultado de solicitud de permisos
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enviarNotificacion()
            } else {
                Toast.makeText(this, "Permiso denegado", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
